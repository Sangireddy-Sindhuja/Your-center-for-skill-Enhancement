import React from 'react';

function Home() {
  return (
    <div className="text-center mt-5">
      <h1>Centre for Skill Enhancement</h1>
      <p>Explore and enroll in skill development programs!</p>
    </div>
  );
}

export default Home;